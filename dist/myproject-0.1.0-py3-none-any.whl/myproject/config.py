# src/myproject/config.py

URL = "https://en.wikipedia.org/wiki/ASEAN"
DATA_FILE = "countries_data.json"
