# MyProject

A production-ready Python project that scrapes data from Wikipedia, processes the data, and logs all activities using the Rich logging library.

## Features
- **Modular Design:** Organized into clear components (scraper, data handler, logger, etc.).
- **Rich Logging:** Using the Rich library to produce colorful, well-structured logs.
- **Automated Testing:** A test suite implemented with pytest.
- **Easy Packaging:** Packaged with setuptools for distribution.

## Installation

1. Clone the repository.
2. Install dependencies:
   ```bash
   pip install -r requirements.txt
